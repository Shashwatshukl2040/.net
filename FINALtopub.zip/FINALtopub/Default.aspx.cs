﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_Click(object sender, EventArgs e)
    {
        string name = Request.Form.Get("fname");
        string lname = Request.Form.Get("lname");
        string phone = Request.Form.Get("phone");
        string email = Request.Form.Get("email");
        string address = Request.Form.Get("address");
        string trid = Request.Form.Get("trid");
        string rb = rbl.SelectedValue.Trim();
        string pp1 = Request.Form.Get("pp1");
        string pp2 = Request.Form.Get("pp2");
        string pp3 = Request.Form.Get("pp3");
        string pp4 = Request.Form.Get("pp4");

        string imagefile = "";

        try
        {
            string sql = "INSERT INTO [dbo].[registration] ([fname],[lname] ,[phone] ,[institution],[email] ,[comite] ,[port_pref1],[port_pref2],[port_pref3],[port_pref4],[trid],[pimage]) values('"+name+"','"+lname+"',"+phone+",'"+address+"','"+email+"','"+rb+"','"+pp1+ "','" + pp2 + "','" + pp3 + "','" + pp4 + "','"+trid+"','"+ imagefile + "')";
            SqlConnection conn = new SqlConnection("Data Source = LAPTOP-R0T4E44V; Database = maatsi; Integrated Security = True; Min Pool Size = 5; Max Pool Size = 1500; ");
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            lblms.Text= "RECORD HAS BEEN SUCCESSFULLY UPDATED";
            lblms.Visible = true;
            conn.Close();
        }
        catch (Exception ex)
        {
            //Console.WriteLine("Exception Occre while creating table:" + e.Message + "\t" + e.GetType());
            lblms.Text = ex.Message.ToString();
            lblms.Visible = true;
        }



    }
}